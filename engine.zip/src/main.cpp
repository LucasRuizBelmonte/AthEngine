#include <iostream>

#include <GL/glew.h>
#include <GLFW/glfw3.h>
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>

#include "fileManager/fileManager.h"
#include "shader/shader.h"

void errorCallback(int error, const char *description)
{
    std::cerr << "GLFW Error " << error << ": " << description << std::endl;
}

void createTriangle(unsigned int &vao, unsigned int &vbo, unsigned int &ebo)
{
    float triangleVertices[] = {
        0.0f, 1.0f, 0.0f,  // Position of vertex 1
        1.0f, 0.0f, 0.0f,  // Color of vertex 1 (Red)
        -1.f, -0.5f, 0.0f, // Position of vertex 2
        0.0f, 1.0f, 0.0f,  // Color of vertex 2 (Green)
        1.0f, -0.5f, 0.0f, // Position of vertex 3
        0.0f, 0.0f, 1.0f   // Color of vertex 3 (Blue)
    };

	unsigned int triangleIndices[] = {
        0, 1, 2
    };

    glGenVertexArrays(1, &vao);
    glGenBuffers(1, &vbo);
    glGenBuffers(1, &ebo);

    glBindVertexArray(vao);

    glBindBuffer(GL_ARRAY_BUFFER, vbo);
    glBufferData(GL_ARRAY_BUFFER, sizeof(triangleVertices), triangleVertices, GL_STATIC_DRAW);

    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, ebo);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(triangleIndices), triangleIndices, GL_STATIC_DRAW);

    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 6 * sizeof(float), (void *)0);
    glEnableVertexAttribArray(0);

    glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 6 * sizeof(float), (void *)(3 * sizeof(float)));
    glEnableVertexAttribArray(1);

    glBindBuffer(GL_ARRAY_BUFFER, 0);

    glBindVertexArray(0);
}

int main()
{
    // Initialize GLFW
    if (!glfwInit())
    {
        std::cerr << "Failed to initialize GLFW" << std::endl;
        return -1;
    }

    // Set GLFW error callback
    glfwSetErrorCallback(errorCallback);

    // Set OpenGL version and profile
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 4);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 1);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

    // Create window
    GLFWwindow *window = glfwCreateWindow(1200, 900, "Virtual Universe!", nullptr, nullptr);
    if (!window)
    {
        std::cerr << "Failed to create GLFW window" << std::endl;
        glfwTerminate();
        return -1;
    }

    // Make OpenGL context current
    glfwMakeContextCurrent(window);

    // Initialize GLEW
    glewExperimental = GL_TRUE;
    if (glewInit() != GLEW_OK)
    {
        std::cerr << "Failed to initialize GLEW" << std::endl;
        glfwDestroyWindow(window);
        glfwTerminate();
        return -1;
    }

    // Create triangle
    unsigned int vao, vbo, ebo;
    createTriangle(vao, vbo, ebo);

    // Initialize shader
    Shader simpleShader;
	simpleShader.init(
		FileManager::read(std::string(ASSET_PATH) + "/shader/shader.vs"),
		FileManager::read(std::string(ASSET_PATH) + "/shader/shader.fs")
	);

	// Get screen dimensions
    int screenWidth, screenHeight;
    glfwGetFramebufferSize(window, &screenWidth, &screenHeight);

    // Camera setup
    glm::vec3 cameraPosition(0.f, 0.f, 2.f);
    glm::vec3 cameraViewDirection(0.f, 0.f, -1.f);

    // Model matrix
    glm::mat4 model(1.f);

    // View matrix
	glm::mat4 view = glm::lookAt(
		cameraPosition,
		cameraPosition + cameraViewDirection,
		glm::vec3(0.f, 1.f, 0.f));

	// Projection matrix
	glm::mat4 projection = glm::perspective(
		(float)glm::radians(90.0f),
		(float)screenWidth / (float)screenHeight,
		0.01f,
		100.0f);

	// Main loop
    while (!glfwWindowShouldClose(window))
    {

		float time = (float)glfwGetTime();

        float red = (std::sin(time * 0.5f) + 1.0f) / 4.0f;
        float green = (std::sin(time * 0.3f) + 1.0f) / 4.0f;
        float blue = (std::sin(time * 0.7f) + 1.0f) / 4.0f;

        glClearColor(red, green, blue, 1.0f);
        glClear(GL_COLOR_BUFFER_BIT);

        {
            simpleShader.use();

            model = glm::rotate(
                glm::mat4(1.f),
                std::sin(time * 0.8f) / 4.f,
                glm::vec3(0.f, 0.f, -1.f));

            simpleShader.setUniform("u_model", model);
            simpleShader.setUniform("u_view", view);
            simpleShader.setUniform("u_proj", projection);

            glBindVertexArray(vao);

            glDrawElements(GL_TRIANGLES, 3, GL_UNSIGNED_INT, 0);

            glBindVertexArray(0);
        }


		glfwSwapBuffers(window);
        glfwPollEvents();
    }


	glDeleteVertexArrays(1, &vao);
    glDeleteBuffers(1, &vbo);
    glDeleteBuffers(1, &ebo);


	glfwDestroyWindow(window);
    glfwTerminate();

    return 0;
}